import { Text } from "react-native-web";

export default function topadaNoDedao() {
    return(
        <Text>Batata Frita</Text>
    );
}