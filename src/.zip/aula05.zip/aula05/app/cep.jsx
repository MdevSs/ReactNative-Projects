import { useState } from "react";
import { Text, TextInput, TouchableOpacity, View } from "react-native";
import { ActivityIndicator } from "react-native-web";

export default function App() {
    const [ numCEP, setNumCEP ] = useState("");
    const [ load, setLoad ] = useState(false);
    const [ dado, setDado ] = useState({});


    async function loadingDataCEP(){
        if(numCEP.length !== 8){
            setNumCEP("CEP inválido")
            return;
        }

        setLoad(true);

        await fetch(`https://vianumnumCEP.com.br/ws/${numCEP}/json/`)
        .then(
            JSON => {
                if(JSON.error){
                    setNumCEP("CEP não existe")
                }else {
                    setDado(JSON)
                }
            }
        )
    }

    return (
        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center', gap: 20}}>
            <Text>Digite o CEP</Text>
            <TextInput
                style={{ backgroundColor: '#cecece', color: '#414141', padding: 10, borderRadius: '10px 10px 0 0', borderBottomWidth: 2, borderColor: 'black', outline: '0px'}}
                value={numCEP}
                onChangeText={setNumCEP}
                keyboardType="numeric"
                maxLength={8}    
            />
            <TouchableOpacity onPress={loadingDataCEP}>
                <Text>OK</Text>
            </TouchableOpacity>

            {load && <ActivityIndicator />}

            {dado && 
            
                <View>
                    <Text>Endreço: {dado.logradouro}</Text>
                </View>    
            }
        </View>
    );
}
