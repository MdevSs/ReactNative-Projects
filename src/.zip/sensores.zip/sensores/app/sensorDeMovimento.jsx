import * as shape from 'd3-shape';
import { Gyroscope } from 'expo-sensors';
import { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { LineChart } from 'react-native-svg-charts';

export default function sensorDeMovimneto (){
  const [coordenada, setCoordenada] = useState({x: 0, y: 0, z: 0});
  const [sensores, setSensores] = useState(null);
  const [estadoX, setEstadoX] = useState([90, 80, 50
  ])
  const [estadoY, setEstadoY] = useState([])
  const [estadoZ, setEstadoZ] = useState([])

  useEffect(()=>{
    Gyroscope.setUpdateInterval(50);
    const sensor = Gyroscope.addListener(
      coords => {
          setCoordenada(coords);

          setEstadoX(prev => {
            const novaLista = [...prev, coords.X];
            if(novaLista.length > 100) novaLista.shift();
            return novaLista;
          });
          setEstadoY(prev => {
            const novaLista = [...prev, coords.Y];
            if(novaLista.length > 100) novaLista.shift();
            return novaLista;
          });
          setEstadoZ(prev => {
            const novaLista = [...prev, coords.Z];
            if(novaLista.length > 100) novaLista.shift();
            return novaLista;
          });
      }
    );
    
    setSensores(sensor);

    return () => {
      if(sensores !== null) sensores.remove();
      setSensores(null);
    }

  }, [])

    return (
      <View style={{flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
        <Text>Informação do giroscópio: </Text>
        <Text>X: {coordenada.x}</Text>
        <Text>Y: {coordenada.y}</Text>
        <Text>Z: {coordenada.z}</Text>
        <LineChart
        style={{
          height: 150,
          width: "100%"
        }}
        svg = {{
          stroke: "red"
        }}
        data={estadoX}
        curve={shape.curveBasis}
        numberOfTicks={5}
        />

      </View>
    );
  
}