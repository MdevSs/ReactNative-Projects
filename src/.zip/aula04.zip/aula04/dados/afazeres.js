export const dados = [
    {
        "id": 0,
        "title": "Organizar a sociedade",
        "completed":  false
    },
    {
        "id": 1,
        "title": "Ampliar direitos",
        "completed": true
    },
    {
        "id": 2,
        "title": "Tomar os meios de produção",
        "completed": false
    },
    {
        "id": 3,
        "title": "Implantar autogestão",
        "completed": false
    },
]