import React, { FlatList, Pressable, Text, TextInput, View } from "react-native";
import { dados } from "@/dados/afazeres";
import { useState } from "react";
import AntDesign from '@expo/vector-icons/AntDesign';



export default function App() {

    const [ lista, setLista] = useState(
        dados.sort(
            (a, b) => b.id - a.id
        )
    );
    const [tarefa, setTarefa] = useState('');

    return (
        <View
            style={{
                flex:1,
                // justifyContent: 'center',
                // alignItems: 'center',
                padding: 30
            }}>
            <Text style={{fontSize: 20}}>Digite uma terafa</Text>
            <View style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 10, padding: 20}}>
                <TextInput 
                    style={{borderWidth: 2, height: 28, width: '100%', padding: 15, borderRadius: 10}}
                    placeholder="Tarefa"
                    placeholderTextColor='gray'
                    value={tarefa}
                    onChangeText={setTarefa}
                />
                <Pressable> <AntDesign name="pluscircle" size={30} color="black" /> </Pressable>
            </View>
            {/* <Pressable style={{ width: '20%', backgroundColor: 'transparent', borderWidth: 2 , textAlign: 'center', borderRadius: 20, fontSize: 15, padding: 5 }}><Text style={{textAlign: 'center'}}> CRIAR </Text></Pressable> */}
            

            <Text style={{fontSize: 20}}>Afazeres: </Text>
            <View style={{
                paddingTop: 10,
                paddingLeft: 20
            }}>
                <FlatList data={lista}
                          keyExtractor={tarefa => tarefa.id}
                          contentContainerStyle={{flexGrow: 1}}
                />

                {
                    // lista.map((e) => (<Text>{e.id+1} - {e.title}</Text>))
                    console.log(tarefa)
                }

            </View>
        </View>
    );
}
